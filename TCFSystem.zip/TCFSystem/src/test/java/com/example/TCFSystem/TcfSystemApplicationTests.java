package com.example.TCFSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TcfSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
