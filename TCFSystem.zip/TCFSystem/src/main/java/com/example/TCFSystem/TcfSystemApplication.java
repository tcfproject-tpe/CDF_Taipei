package com.example.TCFSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TcfSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TcfSystemApplication.class, args);
	}

}
